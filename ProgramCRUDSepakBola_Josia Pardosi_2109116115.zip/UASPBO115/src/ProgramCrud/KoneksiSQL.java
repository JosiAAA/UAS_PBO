/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProgramCrud;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.*;

/**
 *
 * @author ASUS
 */
public class KoneksiSQL {
    public static Connection con;
    public static Statement stmt;
    public static final String DB_URL = "jdbc:mysql://localhost/uas_crud_bola";
    public static String username = "root";
    public static String password = "";

    public static Connection connect(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL,username,password);
            stmt = con.createStatement(); 
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            System.out.println("Koneksi Gagal");
        }
        return con;
       
    }
    public static Statement statement(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL,username,password);
            stmt = con.createStatement(); 
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            System.out.println("Koneksi Gagal");
        }
        return stmt;
       
    }
   
}
