/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ProgramCrud;

/**
 *
 * @author ASUS
 */
public interface CRUDinterface {
     abstract public boolean create_pemain(String a,int b,String c,int d,String e);
     abstract public boolean delete_pemain(String a);
    
}
