/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProgramCrud;

import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class OpsiCRUD extends KoneksiSQL implements CRUDinterface{
    @Override
    public boolean create_pemain(String a,int b,String c,int d,String z){
          try {
            String sql = "INSERT INTO list_pemain VALUES ('"+a+"',"+b+",'"+c+"',"+d+",'"+z+"')";
            String sql2 = "INSERT INTO list_pemain_permanen VALUES ('"+a+"',"+b+",'"+c+"',"+d+",'"+z+"')";
              System.out.println(sql);
                     System.out.println(sql);
            stmt = connect().createStatement();
            stmt.execute(sql);
            stmt.execute(sql2);
            JOptionPane.showMessageDialog(null,"Tambah Data Berhasil");
            
            
               return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Tambah Data Gagal");
            return false;
        }
    }
     public boolean create_pemain_undo(String a,int b,String c,int d,String z){
          try {
            String sql = "INSERT INTO list_pemain VALUES ('"+a+"',"+b+",'"+c+"',"+d+",'"+z+"')";
           
              System.out.println(sql);
                     System.out.println(sql);
            stmt = connect().createStatement();
            stmt.execute(sql);
            
           
            
            
               return true;
        } catch (Exception e) {
           
            return false;
        }
    }
 public boolean delete_pemain(String a){
       try {
            String sql = "DELETE FROM list_pemain WHERE Nama='"+a+"'";
            String sql3 = "INSERT INTO deletedcrud (nama) VALUES ('"+a+"')";
            stmt = connect().createStatement();
            stmt.execute(sql);
            stmt.execute(sql3);
            JOptionPane.showMessageDialog(null,"Hapus Data Berhasil");
            
            
               return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Hapus Data Gagal");
            return false;
        }
    }

    
 
    
}
